/**
 * Created by songhongxi271 on 17/3/14.
 */

import React, { Component } from 'react';
import {AppRegistry,View} from 'react-native';

import PACHeadImageCell from "./PACHeadImageCell";

class PACCell extends Component {
    render() {
        const pops = {
            title:'主标题',
            subTitle:'副标题副标题副标题',
            showTopLine:true,
            showBottomLine:true,
            topLineHasLeftMargin:true,
            bottomLineHasLeftMargin:true,
        };

	    return (<View style={{marginTop:20}}>
                    <PACHeadImageCell {...pops}></PACHeadImageCell>
            </View>
        );
   	}
}
AppRegistry.registerComponent('PACCell', () => PACCell);

export default PACCell;