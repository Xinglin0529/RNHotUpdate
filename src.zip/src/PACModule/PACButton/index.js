/**
 * Created by songhongxi271 on 17/3/14.
 */

import React, { Component } from 'react';
import {
  AppRegistry,
  StyleSheet,
  View,
  Text,
} from 'react-native';

class PACButton extends Component {
	render()
	{
    	return (
    		<View style={{  flex: 1,
                   flexDirection: 'column',
                    paddingTop:20  }}>

                  <Text>PACButtonaaaaa</Text>

                    </View>
        );

    
   	}
}



AppRegistry.registerComponent('PACButton', () => PACButton);


export default PACButton;