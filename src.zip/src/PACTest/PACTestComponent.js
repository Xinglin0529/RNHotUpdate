/**
 * Created by xudongdong121 on 17/3/16.
 */
import React, { Component } from 'react';
import { View, Text, AppRegistry, TouchableOpacity, Image } from 'react-native';
import PACComponent from '../PACModule/PACComponent';

class PACTestComponent extends PACComponent {

    constructor(props) {
        super(props);
        this.title = "PACTestCom";
        this.isAbsolute = true;
        this.backgroundColor = "#f1f1f1";
        this.leftTitle = "Back";
        this.rightTitle = "Next";
        this.itemColor = '#0677da';
    }

    // leftButton() {
    //     return (
    //         <View style={{flex: 1, marginTop: 10, alignItems: 'center', flexDirection: 'row', paddingTop: 3}}>
    //             <TouchableOpacity>
    //                 <Text style={{marginLeft: 14, fontSize: 16, color: '#0677da'}}>Back</Text>
    //             </TouchableOpacity>
    //         </View>
    //     );
    // }
    //
    // rightButton() {
    //     return (
    //         <View style={{flex: 1, marginTop: 5, alignItems: 'center', flexDirection: 'row', justifyContent: 'flex-end'}}>
    //             <TouchableOpacity>
    //                 <Text style={{marginRight: 10, fontSize: 16, color: '#0677da'}}>Next</Text>
    //             </TouchableOpacity>
    //         </View>
    //     );
    // }
    //
    // titleView() {
    //     return (
    //         <View style={{flex: 1, alignItems: 'center', paddingTop: 10, justifyContent: 'center'}}>
    //             <Text style={{fontSize: 18, color: '#4a4a4a'}}>Next</Text>
    //         </View>
    //     );
    // }

    leftButtonAction() {
        alert('LeftAction');
    }

    rightButtonAction(index) {
        alert('RightAction' + index);
    }

    _pushNext() {
        this.props.navigator.push({screen: PACTestComponent, props: { title: 'fromPush' }});
    }

    contentView() {
        return (
            <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                <Text onPress={() => this._pushNext()}> PACTestComponent </Text>
            </View>
        );
    }
}

export default PACTestComponent;
